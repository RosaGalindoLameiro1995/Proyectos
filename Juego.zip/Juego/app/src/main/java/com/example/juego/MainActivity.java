package com.example.juego;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewTreeObserver;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    public Pantalla p;

    //Creamos el Handler

    private Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //miJuego juego = new miJuego(this);

        setContentView(R.layout.activity_main);

        p=(Pantalla)findViewById(R.id.Pantalla);

        ViewTreeObserver obs = p.getViewTreeObserver();
        obs.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                p.anchoRGL=p.getWidth();
                p.altoRGL = p.getHeight();
                //Ahora vamos a definir las posiciones
                p.posX=p.anchoRGL/2;
                p.posY=p.altoRGL-50;
                p.radio=50;
                p.posMonedaY=50;
                //Definimos la posición donde estará el enemigo.
                p.posMonedaFalsaX= 200;


                p.setEscala();
            }
        });







        //Bucle principal del juego

       Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable(){
                    @Override
                            public void run(){
                        p.posMonedaY+=10;
                        p.posMonedaFalsaY+=10;
                        //Regresca la pantalla y llama al método onDraw.
                        p.invalidate();
                    }
                });

            }
        }, 0, 20);


    }

    /*class miJuego extends View {

        public miJuego (Context context){
            super (context);
        }

        @Override
        protected void  onDraw(Canvas canvas){

        }

    }*/
}