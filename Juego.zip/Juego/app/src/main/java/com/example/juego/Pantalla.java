package com.example.juego;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class Pantalla extends View {

    public int anchoMundoRGL, altoMundoRGL, anchoRGL, altoRGL;

    public float escala;

    public int posX, posY, radio,posMonedaY, posMonedaX, posMonedaFalsaX, posMonedaFalsaY;
    private GestureDetector gestos;
    private RectF rectMoneda, rectMonedaFalsa;
    private RectF rectCesta;
    private Integer puntuacion=0;
    private Random random = new Random();



    //Ponemos todos los constructores de la clase View
    public Pantalla (Context context){super (context);}


    public Pantalla(Context context, AttributeSet attrs){
        super(context, attrs);

        //Defino el límite del mundo

        anchoMundoRGL = 1000;
        altoMundoRGL = 1000;

        //Posición inicial de la cesta.

        posX= anchoMundoRGL/2;
        posY = altoMundoRGL/2;

        //Ancho de la pantalla
        radio=50;
    }

    //Pongo el Listener

    @Override
    public boolean onTouchEvent(MotionEvent event){
        switch(event.getAction()){

            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_UP:
                break;
            case MotionEvent.ACTION_MOVE:
                posY= 900;        //(int)event.getY();
                posX=(int)event.getX();
                radio=25;

                this.invalidate();

        }
        return true;
    }

    @Override
    protected void onDraw (Canvas canvas){
        super.onDraw(canvas);
        //Definimos los objetos a pintar

        Paint p1 = new Paint();

        Bitmap bitmapCesta = BitmapFactory.decodeResource(getResources(), R.drawable.cesta);
        Bitmap bitmapFruta = BitmapFactory.decodeResource(getResources(), R.drawable.manzana);
        Bitmap bitmapEnemigo=BitmapFactory.decodeResource(getResources(), R.drawable.enemigo);

        Paint p2 = new Paint(); //El p2 es la cesta.
        Paint monedaRGL = new Paint(); //es la manzana.
        Paint puntos = new Paint();

        //Definimos los colores de los objetos a pintar
        p1.setColor(Color.BLACK);
        p1.setStyle(Paint.Style.FILL_AND_STROKE);

        p2.setColor(Color.YELLOW);
        p2.setStyle(Paint.Style.FILL_AND_STROKE);

        monedaRGL.setColor(Color.RED);
        monedaRGL.setStyle(Paint.Style.FILL_AND_STROKE);


        //Le dotamos de características a "puntos".
        puntos.setTextAlign(Paint.Align.RIGHT);
        puntos.setTextSize(100);
        puntos.setColor(Color.WHITE);

        //Pintamos los rectángulos
        canvas.drawRect(new Rect(0,0, world2screen(anchoMundoRGL),world2screen(altoMundoRGL)),p1);

        //Pinto la pelota o cesta
        rectCesta= new RectF(world2screen(posX-radio),world2screen(posY-radio),
                world2screen(posX+radio), world2screen(posY+radio));
        //canvas.drawOval(rectCesta, p2);

        canvas.drawBitmap(bitmapCesta, null, rectCesta, p2);

        //Pintamos la moneda
        if(posMonedaY>altoRGL){
            posMonedaY=50;
            posMonedaX=random.nextInt(anchoRGL);

        }

        rectMoneda = new RectF((posMonedaX-radio), (posMonedaY-radio),
                (posMonedaX+radio), (posMonedaY+radio));
        //canvas.drawOval(rectMoneda, monedaRGL);

        canvas.drawBitmap(bitmapFruta, null, rectMoneda, monedaRGL);

           //Calculo la intersección
        if(RectF.intersects(rectCesta, rectMoneda)){
            puntuacion += 1;
            posMonedaY=50;
            posMonedaX=random.nextInt(anchoRGL);

        }
        canvas.drawText(puntuacion.toString(), 150, 150, puntos);

        //Pintamos el enemigo
        Paint monedaFalsa = new Paint();
        monedaFalsa.setColor(Color.GREEN); monedaFalsa.setStyle(Paint.Style.FILL_AND_STROKE);
        if (posMonedaFalsaY>altoRGL) {
            posMonedaFalsaY=50; posMonedaFalsaX= random.nextInt(anchoRGL);
        }
        rectMonedaFalsa = new RectF((posMonedaFalsaX-radio),(posMonedaFalsaY-radio),(posMonedaFalsaX+radio), (posMonedaFalsaY+radio));
        //canvas.drawOval(rectMonedaFalsa,monedaFalsa);

        canvas.drawBitmap(bitmapEnemigo, null, rectMonedaFalsa, monedaFalsa);

        // Calculo intersección
        if (RectF.intersects(rectCesta,rectMonedaFalsa)) {
            puntuacion -= 5; posMonedaFalsaY=50;
            posMonedaFalsaX= random.nextInt(anchoRGL);
        }






    }








    public void setEscala(){

        float escalaX, escalaY;
        escalaX=(float)anchoRGL/(float)anchoMundoRGL;
        escalaY=(float)altoRGL/(float)altoMundoRGL;

        escala=Math.min(escalaX,escalaY);
    }

    private int world2screen(int anchoMundoRGL) {

        return (int) (anchoMundoRGL * escala);
    }


}
